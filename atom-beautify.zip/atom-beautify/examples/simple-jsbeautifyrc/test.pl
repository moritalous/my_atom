#!/usr/bin/env perl

use strict;
use warnings;

if(1){
my $x = 'y';
my $foo = 'bar';
# comment

print('Hello, '.'World!')
}
