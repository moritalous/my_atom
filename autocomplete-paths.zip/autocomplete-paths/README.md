# autocomplete-paths package [![Build Status](https://travis-ci.org/saschagehlich/autocomplete-paths.svg?branch=master)](https://travis-ci.org/saschagehlich/autocomplete-paths)

[View the changelog](https://github.com/saschagehlich/autocomplete-paths/blob/master/CHANGELOG.md)

Adds path autocompletion to autocomplete+

![autocomplete-paths](http://s1.directupload.net/images/140411/p5kvife6.gif)

## Installation

You can install autocomplete-paths using the Preferences pane.

**Please make sure you have autocomplete-plus installed as well**
