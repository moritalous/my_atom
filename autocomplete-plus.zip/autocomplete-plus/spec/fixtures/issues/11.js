function Redraw() { }

Redraw.prototype.redraw = function() {
  console.log("foo");
}
