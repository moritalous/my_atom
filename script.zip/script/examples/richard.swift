// Richard Swift - The Shade (DC Comics)

var who = "World"
println("Hello, \(who)!")
